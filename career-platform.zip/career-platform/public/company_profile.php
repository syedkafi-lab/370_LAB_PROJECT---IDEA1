<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

// Check company
$check = $pdo->prepare(
    "SELECT * FROM companies WHERE recruiter_id = ?"
);
$check->execute([$_SESSION["user_id"]]);
$company = $check->fetch(PDO::FETCH_ASSOC);

// Auto-create company
if (!$company) {
    $insert = $pdo->prepare(
        "INSERT INTO companies (recruiter_id) VALUES (?)"
    );
    $insert->execute([$_SESSION["user_id"]]);

    $check->execute([$_SESSION["user_id"]]);
    $company = $check->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Company Profile</title>
</head>
<body>

<h2>Company Profile</h2>

<form method="POST" action="company_profile_update.php">

    Company Name:<br>
    <input type="text" name="company_name"
           value="<?= htmlspecialchars($company["company_name"] ?? "") ?>"><br><br>

    Industry:<br>
    <input type="text" name="industry"
           value="<?= htmlspecialchars($company["industry"] ?? "") ?>"><br><br>

    Location:<br>
    <input type="text" name="location"
           value="<?= htmlspecialchars($company["location"] ?? "") ?>"><br><br>

    Description:<br>
    <textarea name="description"><?= htmlspecialchars($company["description"] ?? "") ?></textarea><br><br>

    <button type="submit">Save Company</button>
</form>

</body>
</html>
