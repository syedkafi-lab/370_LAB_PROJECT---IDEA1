<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$student_id = $_SESSION["user_id"];

$stmt = $pdo->prepare("
    SELECT 
        j.job_id,
        j.title,
        j.is_active,
        c.company_name,
        a.application_id,
        sj.saved_job_id,
        dj.job_id AS dismissed_id
    FROM job_postings j
    JOIN companies c ON j.company_id = c.company_id

    LEFT JOIN applications a 
        ON a.job_id = j.job_id AND a.student_id = ?

    LEFT JOIN saved_jobs sj
        ON sj.job_id = j.job_id AND sj.student_id = ?

    LEFT JOIN dismissed_jobs dj
        ON dj.job_id = j.job_id AND dj.student_id = ?

    WHERE dj.job_id IS NULL
    ORDER BY j.job_id DESC
");
$stmt->execute([$student_id, $student_id, $student_id]);
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>🔍 Browse Jobs</h2>

<?php if (!$jobs): ?>
    <p>No jobs to show.</p>
<?php endif; ?>

<?php foreach ($jobs as $job): ?>
    <div style="border:1px solid #ccc; padding:10px; margin-bottom:10px;">

        <?php if (!$job["is_active"]): ?>
            <strong style="color:red;">
                ❌ <?= htmlspecialchars($job["title"]) ?> — Job Removed
            </strong><br>
            <?= htmlspecialchars($job["company_name"]) ?><br><br>

            <a href="dismiss_job.php?job_id=<?= $job["job_id"] ?>"
               onclick="return confirm('Remove this from your feed?');">
               ✖ Dismiss
            </a>

        <?php else: ?>
            <strong>
                <a href="student_job_view.php?job_id=<?= $job["job_id"] ?>">
                    <?= htmlspecialchars($job["title"]) ?>
                </a>
            </strong><br>
            <?= htmlspecialchars($job["company_name"]) ?><br><br>

            <?php if ($job["application_id"]): ?>
                <span style="color:green;">✅ Already Applied</span>
            <?php else: ?>
                <form method="GET" action="student_apply.php" style="display:inline;">
                    <input type="hidden" name="job_id" value="<?= $job["job_id"] ?>">
                    <button type="submit">Apply</button>
                </form>
            <?php endif; ?>

            <?php if ($job["saved_job_id"]): ?>
                <span style="margin-left:10px;">⭐ Saved</span>
            <?php else: ?>
                <a style="margin-left:10px;" href="student_save_job.php?job_id=<?= $job["job_id"] ?>">
                    💾 Save
                </a>
            <?php endif; ?>

        <?php endif; ?>

    </div>
<?php endforeach; ?>

<a href="student_dashboard.php">⬅ Back</a>
