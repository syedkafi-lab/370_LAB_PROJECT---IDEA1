<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || !isset($_SESSION["role"])) {
    die("Unauthorized");
}

$user_id = $_SESSION["user_id"];
$role = $_SESSION["role"];

$conversation_id = $_POST["conversation_id"] ?? null;
$message = trim($_POST["message"] ?? "");

if (!$conversation_id || $message === "") die("Invalid request.");

/* Verify conversation + ownership + active */
$stmt = $pdo->prepare("SELECT * FROM conversations WHERE conversation_id = ?");
$stmt->execute([$conversation_id]);
$conv = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$conv) die("Conversation not found.");

if ($role === "student" && $conv["student_id"] != $user_id) die("Unauthorized");
if ($role === "recruiter" && $conv["recruiter_id"] != $user_id) die("Unauthorized");

if ($conv["status"] !== "active") die("Chat is not active.");

/* Insert message */
$stmt = $pdo->prepare("
    INSERT INTO messages (conversation_id, sender_role, message)
    VALUES (?, ?, ?)
");
$stmt->execute([$conversation_id, $role, $message]);

header("Location: chat.php?conversation_id=" . $conversation_id);
exit;
