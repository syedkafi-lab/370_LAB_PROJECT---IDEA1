<?php
session_start();
require_once "../config/db.php";

/* ===========================
   AUTH CHECK
=========================== */
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$student_id = $_SESSION["user_id"];

/* ===========================
   ADD SKILL
=========================== */
if ($_SERVER["REQUEST_METHOD"] === "POST" && !empty($_POST["skill"])) {

    // Normalize skill (CRITICAL)
    $skill = strtolower(trim($_POST["skill"]));

    if ($skill !== "") {

        /* Insert skill if not exists */
        $stmt = $pdo->prepare("
            INSERT INTO skills (skill_name)
            VALUES (?)
            ON DUPLICATE KEY UPDATE skill_name = skill_name
        ");
        $stmt->execute([$skill]);

        /* Get skill ID */
        $stmt = $pdo->prepare("
            SELECT skill_id
            FROM skills
            WHERE skill_name = ?
        ");
        $stmt->execute([$skill]);
        $skill_id = $stmt->fetchColumn();

        /* Attach skill to student */
        $stmt = $pdo->prepare("
            INSERT INTO student_skills (student_id, skill_id)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE student_id = student_id
        ");
        $stmt->execute([$student_id, $skill_id]);
    }

    header("Location: student_skills.php");
    exit;
}

/* ===========================
   REMOVE SKILL
=========================== */
if (isset($_GET["remove"])) {

    $stmt = $pdo->prepare("
        DELETE FROM student_skills
        WHERE student_id = ? AND skill_id = ?
    ");
    $stmt->execute([$student_id, $_GET["remove"]]);

    header("Location: student_skills.php");
    exit;
}

/* ===========================
   FETCH STUDENT SKILLS
=========================== */
$stmt = $pdo->prepare("
    SELECT s.skill_id, s.skill_name
    FROM skills s
    JOIN student_skills ss ON s.skill_id = ss.skill_id
    WHERE ss.student_id = ?
    ORDER BY s.skill_name ASC
");
$stmt->execute([$student_id]);
$skills = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Skills</title>
    <meta charset="UTF-8">
</head>
<body>

<h3>🛠 My Skills</h3>

<form method="POST">
    <input type="text" name="skill" placeholder="Add skill (e.g. PHP, MySQL)" required>
    <button type="submit">Add</button>
</form>

<br>

<?php if (!$skills): ?>
    <p>No skills added yet.</p>
<?php else: ?>
    <ul>
        <?php foreach ($skills as $skill): ?>
            <li>
                <?= htmlspecialchars($skill["skill_name"]) ?>
                <a href="?remove=<?= $skill["skill_id"] ?>" onclick="return confirm('Remove this skill?')">❌</a>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<hr>

<a href="student_dashboard.php">⬅ Back to Dashboard</a>

</body>
</html>
