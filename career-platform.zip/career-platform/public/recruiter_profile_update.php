<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

$recruiter_id = $_SESSION["user_id"];

$full_name = trim($_POST["full_name"]);
$designation = trim($_POST["designation"]);
$phone = trim($_POST["phone"]);

$stmt = $pdo->prepare("
    UPDATE recruiters
    SET full_name = ?, designation = ?, phone = ?
    WHERE recruiter_id = ?
");
$stmt->execute([$full_name, $designation, $phone, $recruiter_id]);

header("Location: recruiter_dashboard.php");
exit;
