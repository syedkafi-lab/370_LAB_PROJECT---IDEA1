<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$student_id = $_SESSION["user_id"];

/* ===========================
   MARK APPLICATION NOTIFICATIONS AS READ
=========================== */
$stmt = $pdo->prepare("
    UPDATE notifications
    SET is_read = 1
    WHERE user_id = ?
      AND type IN (
          'job_removed',
          'application_reviewed',
          'application_selected',
          'application_dropped',
          'application_withdrawn'
      )
");
$stmt->execute([$student_id]);

/* ===========================
   FETCH APPLICATIONS + JOB + COMPANY + RATING
=========================== */
$stmt = $pdo->prepare("
    SELECT 
        a.application_id,
        a.status,
        a.applied_at,
        a.recruiter_score,
        a.recruiter_feedback,
        j.title        AS job_title,
        c.company_name
    FROM applications a
    LEFT JOIN job_postings j ON a.job_id = j.job_id
    LEFT JOIN companies c    ON j.company_id = c.company_id
    WHERE a.student_id = ?
    ORDER BY a.applied_at DESC
");
$stmt->execute([$student_id]);
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Applications</title>
    <meta charset="UTF-8">
</head>
<body>

<h2>📄 My Application Status</h2>

<?php if (count($applications) === 0): ?>
    <p>No applications submitted yet.</p>
<?php else: ?>
<table border="1" cellpadding="8">
    <tr>
        <th>Job</th>
        <th>Company</th>
        <th>Status</th>
        <th>Recruiter Rating</th>
        <th>Feedback</th>
        <th>Applied At</th>
        <th>Actions</th>
    </tr>

<?php foreach ($applications as $app): ?>
<tr>

    <!-- JOB TITLE (or Job Removed) -->
    <td><?= htmlspecialchars($app["job_title"] ?? "Job Removed") ?></td>

    <!-- COMPANY (can be null if job removed) -->
    <td><?= htmlspecialchars($app["company_name"] ?? "—") ?></td>

    <!-- STATUS LABEL -->
    <td>
        <?php
            switch ($app["status"]) {
                case "job_removed":
                    echo "<span style='color:red;'>❌ Job Removed</span>";
                    break;
                case "Selected":
                    echo "<span style='color:green;'>🎉 Selected</span>";
                    break;
                case "Dropped":
                    echo "<span style='color:red;'>❌ Dropped</span>";
                    break;
                case "Withdrawn":
                    echo "<span style='color:orange;'>🚪 Withdrawn</span>";
                    break;
                default:
                    echo htmlspecialchars($app["status"]);
                    break;
            }
        ?>
    </td>

    <!-- RECRUITER RATING -->
    <td>
        <?php if ($app["recruiter_score"] !== null): ?>
            ⭐ <?= htmlspecialchars($app["recruiter_score"]) ?>/10
        <?php else: ?>
            Not rated yet
        <?php endif; ?>
    </td>

    <!-- FEEDBACK TEXT -->
    <td>
        <?php
            if (!empty($app["recruiter_feedback"])) {
                echo nl2br(htmlspecialchars($app["recruiter_feedback"]));
            } else {
                echo "No feedback yet";
            }
        ?>
    </td>

    <!-- APPLIED AT -->
    <td><?= htmlspecialchars($app["applied_at"]) ?></td>

    <!-- ACTIONS (WITHDRAW BUTTON) -->
    <td>
        <?php
            $withdraw_allowed_statuses = [
                "Applied",
                "Under Review",
                "Shortlisted",
                "Selected"
            ];

            if (in_array($app["status"], $withdraw_allowed_statuses, true)) :
        ?>
            <form method="POST" action="student_withdraw_application.php"
                  onsubmit="return confirm('Are you sure you want to withdraw this application?');">
                <input type="hidden" name="application_id"
                       value="<?= htmlspecialchars($app["application_id"]) ?>">
                <button type="submit">🚪 Withdraw</button>
            </form>
        <?php else: ?>
            —
        <?php endif; ?>
    </td>

</tr>
<?php endforeach; ?>

</table>
<?php endif; ?>

<br>
<a href="student_dashboard.php">⬅ Back to Dashboard</a>

</body>
</html>
