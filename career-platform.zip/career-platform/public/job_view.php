<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$job_id = $_GET["id"] ?? null;
if (!$job_id) {
    die("Invalid job.");
}

$stmt = $pdo->prepare("
    SELECT j.*, c.company_name
    FROM job_postings j
    JOIN companies c ON j.company_id = c.company_id
    WHERE j.job_id = ?
");
$stmt->execute([$job_id]);
$job = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$job) {
    die("Job not found.");
}

// Check if already applied
$stmt = $pdo->prepare("
    SELECT application_id
    FROM applications
    WHERE student_id = ? AND job_id = ?
");
$stmt->execute([$_SESSION["user_id"], $job_id]);
$applied = $stmt->fetch();
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($job["title"]) ?></title>
</head>
<body>

<h2><?= htmlspecialchars($job["title"]) ?></h2>

<p><strong>Company:</strong> <?= htmlspecialchars($job["company_name"]) ?></p>
<p><strong>Description:</strong><br><?= nl2br(htmlspecialchars($job["description"])) ?></p>
<p><strong>Required Skills:</strong> <?= htmlspecialchars($job["required_skills"]) ?></p>
<p><strong>Minimum GPA:</strong> <?= htmlspecialchars($job["min_gpa"] ?? "N/A") ?></p>
<p><strong>Location:</strong> <?= htmlspecialchars($job["location"]) ?></p>
<p><strong>Type:</strong> <?= htmlspecialchars($job["job_type"]) ?></p>
<p><strong>Stipend/Salary:</strong> <?= htmlspecialchars($job["stipend_salary"]) ?></p>

<hr>

<?php if ($applied): ?>
    <p>✅ You have already applied.</p>
<?php else: ?>
    <form method="POST" action="apply_job.php">
        <input type="hidden" name="job_id" value="<?= $job_id ?>">
        <button type="submit">Apply Now</button>
    </form>
<?php endif; ?>

</body>
</html>
