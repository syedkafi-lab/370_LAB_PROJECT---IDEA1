<?php
require_once "../config/db.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email    = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $role     = $_POST["role"] ?? "";

    if ($email === "" || $password === "" || $role === "") {
        $message = "❌ All fields are required.";
    } else {

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare("
                INSERT INTO users (email, password_hash, role)
                VALUES (:email, :password, :role)
            ");
            $stmt->execute([
                ":email"    => $email,
                ":password" => $hashedPassword,
                ":role"     => $role
            ]);

            // ✅ After successful registration, send user to login
            header("Location: login.php?registered=1");
            exit;

        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                // Duplicate email
                $message = "❌ Email already exists.";
            } else {
                $message = "❌ Error: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Register | Career Platform</title>
    <!-- Bootstrap 5 CDN -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >
</head>
<body class="bg-light">

<div class="min-vh-100 d-flex align-items-center justify-content-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5 col-lg-4">

                <div class="text-center mb-4">
                    <h2 class="fw-bold">Career Platform</h2>
                    <p class="text-muted">Create your account</p>
                </div>

                <div class="card shadow-sm">
                    <div class="card-body">

                        <h4 class="card-title mb-3 text-center">🆕 Register</h4>

                        <?php if ($message !== ""): ?>
                            <div class="alert alert-danger py-2">
                                <?= htmlspecialchars($message) ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" novalidate>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address</label>
                                <input
                                    type="email"
                                    class="form-control"
                                    id="email"
                                    name="email"
                                    required
                                    autocomplete="email"
                                >
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input
                                    type="password"
                                    class="form-control"
                                    id="password"
                                    name="password"
                                    required
                                    autocomplete="new-password"
                                >
                            </div>

                            <div class="mb-3">
                                <label for="role" class="form-label">Role</label>
                                <select
                                    class="form-select"
                                    id="role"
                                    name="role"
                                    required
                                >
                                    <option value="">Select Role</option>
                                    <option value="student">Student</option>
                                    <option value="recruiter">Recruiter</option>
                                </select>
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-success">
                                    Register
                                </button>
                            </div>
                        </form>

                        <p class="mt-3 mb-0 text-center">
                            Already have an account?
                            <a href="login.php">Login here</a>
                        </p>

                        <p class="mt-1 text-center">
                            <a href="index.php" class="text-muted" style="font-size:0.85rem;">
                                ⬅ Back to Home
                            </a>
                        </p>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
