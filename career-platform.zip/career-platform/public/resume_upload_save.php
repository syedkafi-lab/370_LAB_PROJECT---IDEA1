<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$student_id = $_SESSION["user_id"];

if (!isset($_FILES["resume"]) || $_FILES["resume"]["error"] !== UPLOAD_ERR_OK) {
    die("Upload failed.");
}

$original_name = $_FILES["resume"]["name"];
$tmp = $_FILES["resume"]["tmp_name"];
$ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));

if (!in_array($ext, ["pdf", "docx"])) {
    die("Only PDF or DOCX allowed.");
}

$dir = "../uploads/resumes/";
if (!is_dir($dir)) mkdir($dir, 0777, true);

$new_name = time() . "_" . $original_name;
$path = $dir . $new_name;

move_uploaded_file($tmp, $path);

/* 🔴 THIS WAS MISSING BEFORE */
$stmt = $pdo->prepare("
    INSERT INTO resumes (student_id, file_name, file_path)
    VALUES (?, ?, ?)
");
$stmt->execute([$student_id, $new_name, $path]);

header("Location: student_dashboard.php");
exit;
