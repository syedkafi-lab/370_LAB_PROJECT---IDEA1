<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$job_id = $_POST["job_id"] ?? null;
if (!$job_id) {
    die("Invalid request.");
}

$stmt = $pdo->prepare("
    INSERT INTO applications (student_id, job_id)
    VALUES (?, ?)
");

try {
    $stmt->execute([$_SESSION["user_id"], $job_id]);
} catch (PDOException $e) {
    die("You already applied.");
}

header("Location: student_jobs.php");
exit;
