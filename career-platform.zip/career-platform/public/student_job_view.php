<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$student_id = $_SESSION["user_id"];

if (!isset($_GET["job_id"])) {
    die("Job not specified.");
}

$job_id = $_GET["job_id"];

/* FETCH JOB + STUDENT CGPA (BLOCK REMOVED JOBS) */
$stmt = $pdo->prepare("
    SELECT j.*, c.company_name, s.cgpa AS student_cgpa
    FROM job_postings j
    JOIN companies c ON j.company_id = c.company_id
    JOIN students s ON s.student_id = ?
    WHERE j.job_id = ? AND j.is_active = 1
");
$stmt->execute([$student_id, $job_id]);
$job = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$job) {
    echo "<p style='color:red;'>🚫 This job posting has been removed by the recruiter.</p>";
    echo "<a href='student_jobs.php'>⬅ Back to Browse Jobs</a>";
    exit;
}

$gpa_ok = ($job["min_gpa"] === null || $job["student_cgpa"] >= $job["min_gpa"]);

/* FETCH JOB SKILLS */
$stmt = $pdo->prepare("
    SELECT sk.skill_id, sk.skill_name
    FROM job_skills js
    JOIN skills sk ON js.skill_id = sk.skill_id
    WHERE js.job_id = ?
");
$stmt->execute([$job_id]);
$job_skills = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* FETCH STUDENT SKILLS */
$stmt = $pdo->prepare("
    SELECT sk.skill_id, sk.skill_name
    FROM student_skills ss
    JOIN skills sk ON ss.skill_id = sk.skill_id
    WHERE ss.student_id = ?
");
$stmt->execute([$student_id]);
$student_skills = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* MATCH CALCULATION */
$student_skill_ids = array_column($student_skills, "skill_id");
$matched_skills = [];

foreach ($job_skills as $js) {
    if (in_array($js["skill_id"], $student_skill_ids)) {
        $matched_skills[] = $js["skill_name"];
    }
}

$total_required = count($job_skills);
$match_percent = $total_required
    ? round((count($matched_skills) / $total_required) * 100)
    : 0;

/* APPLY CHECK */
$stmt = $pdo->prepare("
    SELECT application_id
    FROM applications
    WHERE student_id = ? AND job_id = ?
");
$stmt->execute([$student_id, $job_id]);
$already_applied = $stmt->fetchColumn();

/* FETCH RESUMES */
$stmt = $pdo->prepare("
    SELECT resume_id, file_name
    FROM resumes
    WHERE student_id = ?
");
$stmt->execute([$student_id]);
$resumes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($job["title"]) ?></title>
    <meta charset="UTF-8">
</head>
<body>

<h2><?= htmlspecialchars($job["title"]) ?></h2>
<p><strong>Company:</strong> <?= htmlspecialchars($job["company_name"]) ?></p>
<p><strong>Location:</strong> <?= htmlspecialchars($job["location"] ?? "N/A") ?></p>
<p><strong>Job Type:</strong> <?= htmlspecialchars($job["job_type"]) ?></p>
<p><strong>Salary:</strong> <?= htmlspecialchars($job["stipend_salary"] ?? "N/A") ?></p>

<p><strong>🎓 Required CGPA:</strong>
    <?= $job["min_gpa"] !== null ? htmlspecialchars($job["min_gpa"]) : "No requirement" ?>
</p>

<?php if (!$gpa_ok): ?>
    <p style="color:red;">
        ❌ Your CGPA (<?= htmlspecialchars($job["student_cgpa"]) ?>) does not meet this requirement.
    </p>
<?php endif; ?>

<hr>

<h3>📄 Job Description</h3>
<p><?= nl2br(htmlspecialchars($job["description"])) ?></p>

<hr>

<h3>🛠 Required Skills</h3>
<?php if ($job_skills): ?>
<ul>
    <?php foreach ($job_skills as $js): ?>
        <li><?= htmlspecialchars($js["skill_name"]) ?></li>
    <?php endforeach; ?>
</ul>
<?php else: ?>
<p>No skills listed.</p>
<?php endif; ?>

<hr>

<h3>🎯 Your Match</h3>
<p><strong><?= $match_percent ?>%</strong> skill match</p>

<?php if ($matched_skills): ?>
<ul>
    <?php foreach ($matched_skills as $ms): ?>
        <li><?= htmlspecialchars($ms) ?></li>
    <?php endforeach; ?>
</ul>
<?php else: ?>
<p>❌ No matching skills yet.</p>
<?php endif; ?>

<hr>

<h3>📤 Apply for this Job</h3>

<?php if ($already_applied): ?>
    <p>✅ You have already applied.</p>

<?php elseif (!$resumes): ?>
    <p>❌ Upload a resume first.</p>
    <a href="resume_upload.php">➕ Upload Resume</a>

<?php elseif (!$gpa_ok): ?>
    <button disabled style="opacity:0.6;">🚫 GPA Requirement Not Met</button>

<?php else: ?>
<form method="POST" action="student_apply_save.php">
    <input type="hidden" name="job_id" value="<?= $job_id ?>">
    <select name="resume_id" required>
        <option value="">-- Select Resume --</option>
        <?php foreach ($resumes as $r): ?>
            <option value="<?= $r["resume_id"] ?>">
                <?= htmlspecialchars($r["file_name"]) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <br><br>
    <button type="submit">🚀 Apply Now</button>
</form>
<?php endif; ?>

<hr>
<a href="student_jobs.php">⬅ Back to Browse Jobs</a>

</body>
</html>
