<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    die("Unauthorized");
}

if (empty($_POST["application_id"])) {
    die("Application ID missing.");
}

$student_id    = (int) $_SESSION["user_id"];
$application_id = (int) $_POST["application_id"];

/* ===========================
   FETCH APPLICATION + RECRUITER
=========================== */
$stmt = $pdo->prepare("
    SELECT 
        a.application_id,
        a.student_id,
        a.status,
        j.job_id,
        j.title       AS job_title,
        j.recruiter_id
    FROM applications a
    JOIN job_postings j ON a.job_id = j.job_id
    WHERE a.application_id = ?
      AND a.student_id = ?
");
$stmt->execute([$application_id, $student_id]);
$app = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$app) {
    die("Application not found.");
}

/* ===========================
   CHECK IF WITHDRAWAL IS ALLOWED
=========================== */
$blocked_statuses = ['Rejected', 'Dropped', 'job_removed', 'Withdrawn'];

if (in_array($app["status"], $blocked_statuses, true)) {
    die("This application cannot be withdrawn.");
}

/* ===========================
   UPDATE APPLICATION -> Withdrawn
=========================== */
$stmt = $pdo->prepare("
    UPDATE applications
    SET status = 'Withdrawn',
        updated_at = NOW()
    WHERE application_id = ?
");
$stmt->execute([$application_id]);

/* ===========================
   LOCK ANY EXISTING CONVERSATION
=========================== */
$stmt = $pdo->prepare("
    UPDATE conversations
    SET status = 'locked'
    WHERE application_id = ?
");
$stmt->execute([$application_id]);


/* ===========================
   NOTIFY RECRUITER
=========================== */
$recruiter_id = (int) $app["recruiter_id"];
$job_title    = $app["job_title"];

$message = "⚠ A student has withdrawn their application for: {$job_title}";

$stmt = $pdo->prepare("
    INSERT INTO notifications (user_id, message, type, is_read, created_at)
    VALUES (?, ?, 'application_withdrawn', 0, NOW())
");
$stmt->execute([$recruiter_id, $message]);

header("Location: student_applications.php");
exit;
