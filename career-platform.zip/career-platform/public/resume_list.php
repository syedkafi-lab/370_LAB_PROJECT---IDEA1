<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$student_id = $_SESSION["user_id"];

$stmt = $pdo->prepare("
    SELECT resume_id, file_name, uploaded_at
    FROM resumes
    WHERE student_id = ?
    ORDER BY uploaded_at DESC
");
$stmt->execute([$student_id]);
$resumes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Resumes</title>
</head>
<body>

<h2>📂 My Resumes</h2>

<?php if (count($resumes) === 0): ?>
    <p>No resumes uploaded yet.</p>
<?php else: ?>

<table border="1" cellpadding="8">
<tr>
    <th>File</th>
    <th>Uploaded At</th>
    <th>Download</th>
</tr>

<?php foreach ($resumes as $r): ?>
<tr>
    <td><?= htmlspecialchars($r["file_name"]) ?></td>
    <td><?= htmlspecialchars($r["uploaded_at"]) ?></td>
    <td>
        <a href="resume_download.php?id=<?= $r['resume_id'] ?>">
            Download
        </a>
    </td>
</tr>
<?php endforeach; ?>

</table>

<?php endif; ?>

<br>
<a href="student_dashboard.php">⬅ Back</a>

</body>
</html>
