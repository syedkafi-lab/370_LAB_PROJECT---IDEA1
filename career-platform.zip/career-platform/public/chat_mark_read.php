<?php
function chat_mark_read(PDO $pdo, int $conversation_id, string $role): void {

    if ($role === "student") {
        $stmt = $pdo->prepare("
            UPDATE messages
            SET read_by_student = 1
            WHERE conversation_id = ?
              AND sender_role = 'recruiter'
              AND read_by_student = 0
        ");
        $stmt->execute([$conversation_id]);

    } elseif ($role === "recruiter") {
        $stmt = $pdo->prepare("
            UPDATE messages
            SET read_by_recruiter = 1
            WHERE conversation_id = ?
              AND sender_role = 'student'
              AND read_by_recruiter = 0
        ");
        $stmt->execute([$conversation_id]);
    }
}
