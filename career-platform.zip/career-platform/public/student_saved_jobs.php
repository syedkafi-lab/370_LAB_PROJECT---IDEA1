<?php
session_start();
require_once "../config/db.php";

$student_id = $_SESSION["user_id"];

$stmt = $pdo->prepare("
    SELECT j.job_id, j.title, c.company_name
    FROM saved_jobs sj
    JOIN job_postings j ON sj.job_id = j.job_id
    JOIN companies c ON j.company_id = c.company_id
    WHERE sj.student_id = ?
");
$stmt->execute([$student_id]);
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>⭐ Saved Jobs</h2>

<?php if (!$jobs): ?>
    <p>No saved jobs.</p>
<?php else: ?>
    <ul>
        <?php foreach ($jobs as $job): ?>
            <li>
                <a href="student_job_view.php?job_id=<?= $job["job_id"] ?>">
                    <?= htmlspecialchars($job["title"]) ?>
                </a>
                – <?= htmlspecialchars($job["company_name"]) ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<a href="student_dashboard.php">⬅ Back</a>
