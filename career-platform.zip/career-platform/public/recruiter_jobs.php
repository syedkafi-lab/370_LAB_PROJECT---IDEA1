<?php
session_start();
require_once "../config/db.php";

/* ===========================
   AUTH CHECK
=========================== */
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

$recruiter_id = $_SESSION["user_id"];

/* ===========================
   FETCH COMPANY (CORRECT TABLE)
=========================== */
$stmt = $pdo->prepare("
    SELECT company_id, company_name
    FROM companies
    WHERE recruiter_id = ?
");
$stmt->execute([$recruiter_id]);
$company = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$company) {
    die("Company not found. Please create a company profile first.");
}

/* ===========================
   FETCH JOBS (OWN COMPANY ONLY)
=========================== */
$stmt = $pdo->prepare("
    SELECT 
        j.job_id,
        j.title,
        j.job_type,
        j.location,
        j.min_gpa,
        j.is_active,
        j.created_at
    FROM job_postings j
    WHERE j.company_id = ?
    ORDER BY j.created_at DESC
");
$stmt->execute([$company["company_id"]]);
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Job Posts</title>
    <meta charset="UTF-8">
</head>
<body>

<h2>📌 My Job Posts — <?= htmlspecialchars($company["company_name"]) ?></h2>

<a href="job_create.php">➕ Post New Job</a>
<br><br>

<?php if (empty($jobs)): ?>
    <p>No jobs posted yet.</p>
<?php else: ?>

<table border="1" cellpadding="8">
    <tr>
        <th>Title</th>
        <th>Type</th>
        <th>Location</th>
        <th>Min GPA</th>
        <th>Status</th>
        <th>Posted On</th>
        <th>Actions</th>
    </tr>

    <?php foreach ($jobs as $job): ?>
    <tr>
        <td><?= htmlspecialchars($job["title"]) ?></td>
        <td><?= htmlspecialchars($job["job_type"]) ?></td>
        <td><?= htmlspecialchars($job["location"] ?? "N/A") ?></td>

        <td>
            <?= $job["min_gpa"] !== null ? htmlspecialchars($job["min_gpa"]) : "None" ?>
        </td>

        <td>
            <?= $job["is_active"] ? "🟢 Active" : "🔴 Inactive" ?>
        </td>

        <td><?= htmlspecialchars($job["created_at"]) ?></td>

        <td>
            <a href="recruiter_applications.php?job_id=<?= $job["job_id"] ?>">
                👥 Applications
            </a>
            <br>

            <?php if ($job["is_active"]): ?>
                <a href="recruiter_job_edit.php?job_id=<?= $job["job_id"] ?>">
                    ✏️ Edit
                </a>
                |
                <a href="recruiter_job_delete.php?job_id=<?= $job["job_id"] ?>"
                   onclick="return confirm('This will deactivate the job and notify applicants. Continue?');">
                    🗑 Delete
                </a>
            <?php else: ?>
                <em>Job closed</em>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>

</table>

<?php endif; ?>

<br>
<a href="recruiter_dashboard.php">⬅ Back to Dashboard</a>

</body>
</html>
