<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$student_id = $_SESSION["user_id"];

$stmt = $pdo->prepare("
UPDATE students SET
    full_name = ?,
    university = ?,
    major = ?,
    cgpa = ?,
    graduation_year = ?
WHERE student_id = ?
");

$stmt->execute([
    $_POST['full_name'],
    $_POST['university'],
    $_POST['major'],
    $_POST['cgpa'],
    $_POST['graduation_year'],
    $student_id
]);

header("Location: student_dashboard.php");
exit;
