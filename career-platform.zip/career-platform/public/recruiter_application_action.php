<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    die("Unauthorized");
}

if (!isset($_POST["application_id"], $_POST["action"])) {
    die("Invalid request");
}

$recruiter_id   = $_SESSION["user_id"];
$application_id = (int) $_POST["application_id"];
$action         = $_POST["action"];

if (!in_array($action, ["select", "drop"])) {
    die("Invalid action");
}

$new_status = ($action === "select") ? "Selected" : "Dropped";

/* ===========================
   VERIFY OWNERSHIP
=========================== */
$stmt = $pdo->prepare("
    SELECT a.application_id, a.student_id, a.job_id, j.title
    FROM applications a
    JOIN job_postings j ON a.job_id = j.job_id
    JOIN companies c ON j.company_id = c.company_id
    WHERE a.application_id = ?
      AND c.recruiter_id = ?
");
$stmt->execute([$application_id, $recruiter_id]);
$app = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$app) {
    die("Unauthorized access");
}

/* ===========================
   UPDATE STATUS (CRITICAL)
=========================== */
$stmt = $pdo->prepare("
    UPDATE applications
    SET status = ?, updated_at = NOW()
    WHERE application_id = ?
");
$stmt->execute([$new_status, $application_id]);

/* VERIFY UPDATE */
if ($stmt->rowCount() === 0) {
    die("Status update failed. Check ENUM values.");
}

/* ===========================
   NOTIFICATION
=========================== */
$message = ($new_status === "Selected")
    ? "🎉 You have been selected for interview for '{$app["title"]}'."
    : "❌ Your application was declined for '{$app["title"]}'.";

$stmt = $pdo->prepare("
    INSERT INTO notifications (user_id, message, created_at)
    VALUES (?, ?, NOW())
");
$stmt->execute([$app["student_id"], $message]);

header("Location: " . $_SERVER["HTTP_REFERER"]);
exit;
