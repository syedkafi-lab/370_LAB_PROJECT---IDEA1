<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

$recruiter_id = $_SESSION["user_id"];

if (!isset($_GET["job_id"])) {
    die("Job ID missing.");
}

$job_id = $_GET["job_id"];

/* VERIFY JOB OWNERSHIP */
$stmt = $pdo->prepare("
    SELECT j.*
    FROM job_postings j
    JOIN companies c ON j.company_id = c.company_id
    WHERE j.job_id = ? AND c.recruiter_id = ?
");
$stmt->execute([$job_id, $recruiter_id]);
$job = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$job) {
    die("Unauthorized access.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Job</title>
</head>
<body>

<h2>✏️ Edit Job Posting</h2>

<form method="POST" action="recruiter_job_update.php">
    <input type="hidden" name="job_id" value="<?= $job_id ?>">

    <label>Job Title:</label><br>
    <input type="text" name="title"
           value="<?= htmlspecialchars($job["title"]) ?>" required><br><br>

    <label>Description:</label><br>
    <textarea name="description" rows="5" required><?= htmlspecialchars($job["description"]) ?></textarea><br><br>

    <label>Minimum GPA:</label><br>
    <input type="number" step="0.01" name="min_gpa"
           value="<?= htmlspecialchars($job["min_gpa"]) ?>"><br><br>

    <button type="submit">💾 Save Changes</button>
</form>

<br>
<a href="recruiter_jobs.php">⬅ Back</a>

</body>
</html>
