<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    die("Unauthorized");
}

if (!isset($_GET["job_id"])) {
    die("Job ID missing");
}

$student_id = $_SESSION["user_id"];
$job_id = $_GET["job_id"];

$stmt = $pdo->prepare("
    INSERT IGNORE INTO dismissed_jobs (student_id, job_id)
    VALUES (?, ?)
");
$stmt->execute([$student_id, $job_id]);

header("Location: student_jobs.php");
exit;
