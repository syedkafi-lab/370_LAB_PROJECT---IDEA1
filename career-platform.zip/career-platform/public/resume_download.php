<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    die("Unauthorized");
}

$student_id = $_SESSION["user_id"];
$resume_id = $_GET["id"] ?? 0;

$stmt = $pdo->prepare("
    SELECT file_name, file_path
    FROM resumes
    WHERE resume_id = ? AND student_id = ?
");
$stmt->execute([$resume_id, $student_id]);
$resume = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$resume) {
    die("File not found.");
}

$file = $resume["file_path"];

if (!file_exists($file)) {
    die("File missing on server.");
}

header("Content-Description: File Transfer");
header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=\"" . basename($resume["file_name"]) . "\"");
header("Content-Length: " . filesize($file));
readfile($file);
exit;
