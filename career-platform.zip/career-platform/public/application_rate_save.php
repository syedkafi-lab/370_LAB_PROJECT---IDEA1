<?php
session_start();
require_once "../config/db.php";

/* ===========================
   AUTH CHECK
=========================== */
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

if (
    empty($_POST["application_id"]) ||
    !isset($_POST["recruiter_score"])
) {
    die("Invalid request.");
}

$application_id = $_POST["application_id"];
$score = $_POST["recruiter_score"];
$feedback = trim($_POST["recruiter_feedback"] ?? "");

/* ===========================
   UPDATE APPLICATION
=========================== */
$stmt = $pdo->prepare("
    UPDATE applications
    SET recruiter_score = ?,
        recruiter_feedback = ?,
        rated_at = NOW(),
        status = 'Reviewed'
    WHERE application_id = ?
");
$stmt->execute([$score, $feedback, $application_id]);

/* ===========================
   FETCH STUDENT ID
=========================== */
$stmt = $pdo->prepare("
    SELECT student_id
    FROM applications
    WHERE application_id = ?
");
$stmt->execute([$application_id]);
$student_id = $stmt->fetchColumn();

/* ===========================
   CREATE NOTIFICATION
=========================== */
if ($student_id) {
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, type, message)
        VALUES (?, 'application_reviewed', ?)
    ");

    $stmt->execute([
        $student_id,
        'Your application has been reviewed and rated by the recruiter.'
    ]);
}

header("Location: " . $_SERVER["HTTP_REFERER"]);
exit;
