<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

$recruiter_id = $_SESSION["user_id"];
$job_id = $_GET["job_id"] ?? die("Job ID missing.");

/* VERIFY JOB OWNERSHIP + GET MIN GPA */
$stmt = $pdo->prepare("
    SELECT j.job_id, j.title, j.min_gpa
    FROM job_postings j
    JOIN companies c ON j.company_id = c.company_id
    WHERE j.job_id = ? AND c.recruiter_id = ?
");
$stmt->execute([$job_id, $recruiter_id]);
$job = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$job) die("Unauthorized access.");

/* FETCH APPLICATIONS (EXCLUDE SELECTED) */
$stmt = $pdo->prepare("
    SELECT 
        a.application_id,
        COALESCE(a.status,'Applied') AS status,
        a.applied_at,
        a.recruiter_score,
        a.recruiter_feedback,

        s.student_id,
        s.full_name,
        s.cgpa,
        u.email,
        r.file_path,

        COUNT(DISTINCT js.skill_id) AS matched,
        (
            COUNT(DISTINCT js.skill_id) /
            NULLIF((SELECT COUNT(*) FROM job_skills WHERE job_id = a.job_id),0)
        ) * 100 AS match_percent

    FROM applications a
    JOIN students s ON a.student_id = s.student_id
    JOIN users u ON s.student_id = u.user_id
    LEFT JOIN resumes r ON a.resume_id = r.resume_id

    LEFT JOIN student_skills ss ON ss.student_id = s.student_id
    LEFT JOIN job_skills js 
        ON js.skill_id = ss.skill_id
       AND js.job_id = a.job_id

    WHERE a.job_id = ?
      AND (a.status IS NULL OR a.status <> 'Selected')

    GROUP BY a.application_id
    ORDER BY a.applied_at DESC
");
$stmt->execute([$job_id]);
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Applications</title>
    <meta charset="UTF-8">
</head>
<body>

<h2>📄 Applications for <?= htmlspecialchars($job["title"]) ?></h2>
<p>🎓 Minimum GPA Required: <?= $job["min_gpa"] ?? "None" ?></p>

<a href="recruiter_jobs.php">⬅ Back</a>
&nbsp; | &nbsp;
<a href="recruiter_selected_applicants.php?job_id=<?= $job_id ?>">✅ Saved/Selected Applicants</a>

<hr>

<?php if (!$applications): ?>
    <p>No applications here (or all selected).</p>
<?php else: ?>

<table border="1" cellpadding="8">
<tr>
    <th>Student</th>
    <th>Email</th>
    <th>CGPA</th>
    <th>GPA OK</th>
    <th>Skill Match</th>
    <th>Resume</th>
    <th>Status</th>
    <th>Rating</th>
    <th>Feedback</th>
    <th>Actions</th>
</tr>

<?php foreach ($applications as $app): 
    $min_gpa = $job["min_gpa"];
    $gpa_ok  = ($min_gpa === null || $app["cgpa"] >= $min_gpa);

    // allow actions unless already dropped/job_removed
    $can_act = !in_array($app["status"], ["Dropped", "job_removed"]);
?>

<tr>
    <td><?= htmlspecialchars($app["full_name"]) ?></td>
    <td><?= htmlspecialchars($app["email"]) ?></td>
    <td><?= htmlspecialchars($app["cgpa"] ?? "N/A") ?></td>
    <td><?= $gpa_ok ? "✅" : "❌" ?></td>
    <td><?= round($app["match_percent"] ?? 0) ?>%</td>

    <td>
        <?php if (!empty($app["file_path"])): ?>
            <a href="<?= htmlspecialchars($app["file_path"]) ?>" target="_blank">📥</a>
        <?php else: ?>
            —
        <?php endif; ?>
    </td>

    <td><?= htmlspecialchars($app["status"]) ?></td>

    <!-- rating + feedback -->
    <td>
        <form method="POST" action="application_rate_save.php">
            <input type="hidden" name="application_id" value="<?= $app["application_id"] ?>">
            <select name="recruiter_score">
                <option value="">--</option>
                <?php for ($i=1;$i<=10;$i++): ?>
                    <option value="<?= $i ?>" <?= ($app["recruiter_score"]==$i)?"selected":"" ?>>
                        <?= $i ?>
                    </option>
                <?php endfor; ?>
            </select>
    </td>

    <td>
            <input type="text" name="recruiter_feedback"
                   value="<?= htmlspecialchars($app["recruiter_feedback"] ?? "") ?>">
            <button type="submit">💾 Save</button>
        </form>
    </td>

    <!-- select/drop -->
    <td>
        <?php if ($can_act): ?>
            <form method="POST" action="recruiter_application_action.php" style="display:inline;">
                <input type="hidden" name="application_id" value="<?= $app["application_id"] ?>">
                <input type="hidden" name="action" value="select">
                <button <?= !$gpa_ok ? "disabled" : "" ?>>✅ Select</button>
            </form>

            <form method="POST" action="recruiter_application_action.php" style="display:inline;">
                <input type="hidden" name="application_id" value="<?= $app["application_id"] ?>">
                <input type="hidden" name="action" value="drop">
                <button>❌ Drop</button>
            </form>
        <?php else: ?>
            —
        <?php endif; ?>
    </td>

</tr>
<?php endforeach; ?>
</table>

<?php endif; ?>

</body>
</html>
