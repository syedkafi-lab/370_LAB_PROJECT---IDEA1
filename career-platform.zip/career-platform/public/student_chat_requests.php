<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$student_id = (int)$_SESSION["user_id"];

$stmt = $pdo->prepare("
    SELECT 
        conv.conversation_id,
        conv.created_at,
        j.title AS job_title,
        u.email AS recruiter_email
    FROM conversations conv
    JOIN applications a ON conv.application_id = a.application_id
    LEFT JOIN job_postings j ON a.job_id = j.job_id
    JOIN users u ON conv.recruiter_id = u.user_id
    WHERE conv.student_id = ?
      AND conv.status = 'pending'
      AND conv.student_hidden = 0
    ORDER BY conv.created_at DESC
");
$stmt->execute([$student_id]);
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Chat Requests</title>
  <meta charset="UTF-8">
</head>
<body>

<h2>💬 Chat Requests</h2>

<a href="student_chats.php">📥 My Chats (Inbox)</a>
<hr>

<?php if (!$requests): ?>
  <p>No chat requests right now.</p>
<?php else: ?>
  <table border="1" cellpadding="8">
    <tr>
      <th>Job</th>
      <th>Recruiter</th>
      <th>Requested At</th>
      <th>Action</th>
    </tr>

    <?php foreach ($requests as $r): ?>
    <tr>
      <td><?= htmlspecialchars($r["job_title"] ?? "Job Removed") ?></td>
      <td><?= htmlspecialchars($r["recruiter_email"]) ?></td>
      <td><?= htmlspecialchars($r["created_at"]) ?></td>
      <td>
        <form method="POST" action="student_chat_accept.php">
          <input type="hidden" name="conversation_id" value="<?= (int)$r["conversation_id"] ?>">
          <button type="submit">✅ Accept</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
<?php endif; ?>

<br>
<a href="student_dashboard.php">⬅ Back</a>

</body>
</html>
