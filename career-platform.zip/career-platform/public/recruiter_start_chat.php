<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    die("Unauthorized");
}

if (empty($_POST["application_id"])) {
    die("Application ID missing");
}

$recruiter_id = $_SESSION["user_id"];
$application_id = (int)$_POST["application_id"];

/* Verify recruiter owns this application and it's Selected */
$stmt = $pdo->prepare("
    SELECT a.student_id, a.job_id, j.title
    FROM applications a
    JOIN job_postings j ON a.job_id = j.job_id
    JOIN companies c ON j.company_id = c.company_id
    WHERE a.application_id = ?
      AND a.status = 'Selected'
      AND c.recruiter_id = ?
");
$stmt->execute([$application_id, $recruiter_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    die("Chat not allowed or unauthorized.");
}

$student_id = (int)$row["student_id"];
$job_title = $row["title"];

/* Create conversation (unique per application) */
try {
    $stmt = $pdo->prepare("
        INSERT INTO conversations (application_id, recruiter_id, student_id, status)
        VALUES (?, ?, ?, 'pending')
    ");
    $stmt->execute([$application_id, $recruiter_id, $student_id]);
} catch (PDOException $e) {
    // If already exists, ignore
}

/* Notify student */
$stmt = $pdo->prepare("
    INSERT INTO notifications (user_id, message, is_read, created_at)
    VALUES (?, ?, 0, NOW())
");
$stmt->execute([$student_id, "💬 A recruiter sent you a chat request for: {$job_title}"]);

header("Location: recruiter_selected_applicants.php");
exit;
