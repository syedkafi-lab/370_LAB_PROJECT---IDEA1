<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$student_id = (int)$_SESSION["user_id"];

/* Chats visible to student (not dismissed) */
$stmt = $pdo->prepare("
    SELECT 
        c.conversation_id,
        c.status,
        c.created_at,
        a.application_id,
        a.status AS app_status,
        j.title AS job_title,
        co.company_name,

        (SELECT message FROM messages m WHERE m.conversation_id = c.conversation_id ORDER BY m.sent_at DESC LIMIT 1) AS last_msg,
        (SELECT sent_at  FROM messages m WHERE m.conversation_id = c.conversation_id ORDER BY m.sent_at DESC LIMIT 1) AS last_time,

        (SELECT COUNT(*)
         FROM messages m2
         WHERE m2.conversation_id = c.conversation_id
           AND m2.sender_role = 'recruiter'
           AND m2.read_by_student = 0
        ) AS unread_count

    FROM conversations c
    JOIN applications a ON c.application_id = a.application_id
    LEFT JOIN job_postings j ON a.job_id = j.job_id
    LEFT JOIN companies co ON j.company_id = co.company_id
    WHERE c.student_id = ?
      AND c.student_hidden = 0
    ORDER BY 
        CASE c.status WHEN 'pending' THEN 1 WHEN 'active' THEN 2 WHEN 'locked' THEN 3 ELSE 4 END,
        COALESCE(last_time, c.created_at) DESC
");
$stmt->execute([$student_id]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Chats</title>
    <meta charset="UTF-8">
</head>
<body>

<h2>💬 My Chats</h2>

<?php if (!$rows): ?>
    <p>No chats yet.</p>
<?php else: ?>
<table border="1" cellpadding="8">
<tr>
    <th>Job</th>
    <th>Company</th>
    <th>Status</th>
    <th>Unread</th>
    <th>Last Message</th>
    <th>Action</th>
</tr>

<?php foreach ($rows as $r): ?>
<tr>
    <td><?= htmlspecialchars($r["job_title"] ?? "Job Removed") ?></td>
    <td><?= htmlspecialchars($r["company_name"] ?? "—") ?></td>

    <td>
        <?php
            if ($r["status"] === "pending") echo "⏳ Pending (Accept required)";
            elseif ($r["status"] === "active") echo "✅ Active";
            elseif ($r["status"] === "locked") echo "🔒 Locked";
            else echo "🚫 Ended";
        ?>
    </td>

    <td>
        <?php if ((int)$r["unread_count"] > 0): ?>
            <strong style="color:red;"><?= (int)$r["unread_count"] ?></strong>
        <?php else: ?>
            —
        <?php endif; ?>
    </td>

    <td>
        <?= $r["last_msg"] ? htmlspecialchars($r["last_msg"]) : "—" ?>
        <?php if ($r["last_time"]): ?>
            <br><small><?= htmlspecialchars($r["last_time"]) ?></small>
        <?php endif; ?>
    </td>

    <td>
        <?php if ($r["status"] === "pending"): ?>
            <form method="POST" action="student_chat_accept.php" style="display:inline;">
                <input type="hidden" name="conversation_id" value="<?= (int)$r["conversation_id"] ?>">
                <button type="submit">✅ Accept</button>
            </form>

        <?php else: ?>
            <a href="chat.php?conversation_id=<?= (int)$r["conversation_id"] ?>">💬 Open Chat</a>

            <?php if (in_array($r["status"], ["ended","locked"])): ?>
                <form method="POST" action="chat_dismiss.php" style="display:inline;"
                      onsubmit="return confirm('Dismiss this chat from your inbox?');">
                    <input type="hidden" name="conversation_id" value="<?= (int)$r["conversation_id"] ?>">
                    <button type="submit">🗑 Dismiss</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>

</table>
<?php endif; ?>

<br>
<a href="student_dashboard.php">⬅ Back to Dashboard</a>

</body>
</html>
