<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int) $_SESSION["user_id"];
$role    = $_SESSION["role"] ?? null;

if (!isset($_GET["conversation_id"])) {
    die("Conversation not specified.");
}

$conversation_id = (int) $_GET["conversation_id"];

/* ===========================
   FETCH CONVERSATION CONTEXT
=========================== */
$stmt = $pdo->prepare("
    SELECT 
        c.conversation_id,
        c.application_id,
        c.recruiter_id,
        c.student_id,
        c.status,
        c.created_at,

        a.job_id,
        j.title            AS job_title,
        s.full_name        AS student_name,
        r.full_name        AS recruiter_name
    FROM conversations c
    JOIN applications  a ON c.application_id = a.application_id
    JOIN job_postings  j ON a.job_id       = j.job_id
    JOIN students      s ON a.student_id   = s.student_id
    JOIN recruiters    r ON j.recruiter_id = r.recruiter_id
    WHERE c.conversation_id = ?
");
$stmt->execute([$conversation_id]);
$conv = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$conv) {
    die("Conversation not found.");
}

/* ===========================
   MEMBERSHIP CHECK
=========================== */
if ($role === "student" && (int)$conv["student_id"] !== $user_id) {
    die("Unauthorized.");
}
if ($role === "recruiter" && (int)$conv["recruiter_id"] !== $user_id) {
    die("Unauthorized.");
}

$conv_status = $conv["status"];

/* ===========================
   SEND NEW MESSAGE
=========================== */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["message_text"])) {

    if ($conv_status === "active") {

        $text = trim($_POST["message_text"]);

        if ($text !== "") {
            $stmt = $pdo->prepare("
                INSERT INTO messages (
                    conversation_id,
                    sender_id,
                    sender_role,
                    message,
                    sent_at
                ) VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $conversation_id,
                $user_id,
                $role,
                $text
            ]);
        }
    }

    header("Location: chat.php?conversation_id=" . $conversation_id);
    exit;
}

/* ===========================
   MARK READ
=========================== */
if ($role === "recruiter") {
    $pdo->prepare("
        UPDATE messages
        SET read_by_recruiter = 1
        WHERE conversation_id = ?
    ")->execute([$conversation_id]);

} else {
    $pdo->prepare("
        UPDATE messages
        SET read_by_student = 1
        WHERE conversation_id = ?
    ")->execute([$conversation_id]);
}

/* ===========================
   FETCH MESSAGES (DYNAMIC NAME)
=========================== */
$stmt = $pdo->prepare("
    SELECT 
        m.message_id,
        m.message,
        m.sender_id,
        m.sender_role,
        m.sent_at,

        CASE 
            WHEN m.sender_role = 'recruiter'
                THEN (SELECT full_name FROM recruiters WHERE recruiter_id = m.sender_id)
            ELSE
                (SELECT full_name FROM students WHERE student_id = m.sender_id)
        END AS sender_name

    FROM messages m
    WHERE m.conversation_id = ?
    ORDER BY m.sent_at ASC
");
$stmt->execute([$conversation_id]);
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* ===========================
   BACK URL
=========================== */
$back_url = ($role === "recruiter")
    ? "recruiter_selected_applicants.php"
    : "student_chats.php";

?>

<!DOCTYPE html>
<html>
<head>
    <title>Chat – <?= htmlspecialchars($conv["job_title"]) ?></title>
    <meta charset="UTF-8">
</head>
<body>

<h2>💬 Chat for: <?= htmlspecialchars($conv["job_title"]) ?></h2>
<p>
    👨‍💼 Recruiter: <strong><?= htmlspecialchars($conv["recruiter_name"]) ?></strong><br>
    🎓 Student: <strong><?= htmlspecialchars($conv["student_name"]) ?></strong>
</p>

<p>
    Chat Status:
    <?php
        if ($conv_status === "pending") {
            echo "⏳ Pending";
        } elseif ($conv_status === "active") {
            echo "✅ Active";
        } elseif ($conv_status === "locked") {
            echo "🔒 Locked (withdrawn)";
        } elseif ($conv_status === "ended") {
            echo "🛑 Ended";
        } else {
            echo htmlspecialchars($conv_status);
        }
    ?>
</p>

<hr>

<!-- MESSAGES -->
<div style="border:1px solid #ccc; padding:10px; max-width:600px;">
    <?php if (!$messages): ?>
        <p>No messages yet.</p>
    <?php else: ?>
        <?php foreach ($messages as $m): ?>
            <div style="margin-bottom:8px;">
                <strong><?= htmlspecialchars($m["sender_name"]) ?>:</strong>
                <?= nl2br(htmlspecialchars($m["message"])) ?><br>
                <small><?= htmlspecialchars($m["sent_at"]) ?></small>
            </div>
            <hr>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<br>

<!-- SEND FORM -->
<?php if ($conv_status === "active"): ?>
    <form method="POST" action="chat.php?conversation_id=<?= $conversation_id ?>">
        <textarea name="message_text" rows="3" cols="60" placeholder="Type your message..."></textarea><br><br>
        <button type="submit">Send</button>
    </form>

    <form method="POST" action="chat_end.php"
          onsubmit="return confirm('End this chat?');"
          style="margin-top:10px;">
        <input type="hidden" name="conversation_id" value="<?= $conversation_id ?>">
        <button type="submit">🛑 End Chat</button>
    </form>

<?php else: ?>
    <p><em>Chat is read-only.</em></p>
<?php endif; ?>

<br>
<a href="<?= $back_url ?>">⬅ Back</a>

</body>
</html>
