<?php
require "../config/db.php";
session_start();

if (!isset($_SESSION["user_id"])) {
    die("Unauthorized");
}

if (empty($_POST["conversation_id"])) {
    die("Missing conversation ID");
}

$conversation_id = (int)$_POST["conversation_id"];
$user_id = $_SESSION["user_id"];

$stmt = $pdo->prepare("
    INSERT IGNORE INTO dismissed_chats (conversation_id, user_id)
    VALUES (?, ?)
");
$stmt->execute([$conversation_id, $user_id]);

header("Location: " . $_SERVER["HTTP_REFERER"]);
exit;
