<?php
session_start();
require_once "../config/db.php";

$conversation_id = $_GET["conversation_id"] ?? null;
if (!$conversation_id) exit;

$stmt = $pdo->prepare("
    SELECT sender_role, message, sent_at
    FROM messages
    WHERE conversation_id = ?
    ORDER BY sent_at ASC
");
$stmt->execute([$conversation_id]);
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($messages as $m) {
    echo "<p><strong>{$m['sender_role']}:</strong> "
        . htmlspecialchars($m["message"]) .
        " <small>{$m['sent_at']}</small></p>";
}
