<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$student_id = $_SESSION["user_id"];

/* FETCH STUDENT INFO */
$stmt = $pdo->prepare("
    SELECT s.*, u.email
    FROM students s
    JOIN users u ON s.student_id = u.user_id
    WHERE s.student_id = ?
");
$stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    die("Student profile not found.");
}

$student_cgpa = $student["cgpa"];

/* SKILLS */
$stmt = $pdo->prepare("
    SELECT sk.skill_name
    FROM skills sk
    JOIN student_skills ss ON sk.skill_id = ss.skill_id
    WHERE ss.student_id = ?
");
$stmt->execute([$student_id]);
$student_skills = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* RESUME COUNT */
$stmt = $pdo->prepare("SELECT COUNT(*) FROM resumes WHERE student_id = ?");
$stmt->execute([$student_id]);
$resume_count = $stmt->fetchColumn();

/* APPLICATION COUNT */
$stmt = $pdo->prepare("SELECT COUNT(*) FROM applications WHERE student_id = ?");
$stmt->execute([$student_id]);
$application_count = $stmt->fetchColumn();

/* UNREAD NOTIFICATIONS */
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM notifications
    WHERE user_id = ?
      AND is_read = 0
");
$stmt->execute([$student_id]);
$unread_notifications = $stmt->fetchColumn();

/* PENDING CHAT REQUESTS */
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM conversations
    WHERE student_id = ?
      AND status = 'pending'
");
$stmt->execute([$student_id]);
$pending_chats = $stmt->fetchColumn();

/* ==========================
   RECOMMENDED JOBS
========================== */
$stmt = $pdo->prepare("
    SELECT 
        j.job_id,
        j.title,
        c.company_name,
        j.min_gpa,
        COUNT(DISTINCT js.skill_id) AS matched_skills,
        (
            COUNT(DISTINCT js.skill_id) /
            (SELECT COUNT(*) FROM job_skills WHERE job_id = j.job_id)
        ) * 100 AS match_percent,
        CASE
            WHEN j.min_gpa IS NULL THEN 1
            WHEN j.min_gpa <= :student_cgpa THEN 1
            ELSE 0
        END AS gpa_eligible
    FROM job_postings j
    JOIN companies c ON j.company_id = c.company_id
    JOIN job_skills js ON j.job_id = js.job_id
    JOIN student_skills ss ON ss.student_id = :student_id
    WHERE js.skill_id = ss.skill_id
      AND j.is_active = 1
    GROUP BY j.job_id
    HAVING match_percent > 0
    ORDER BY 
        gpa_eligible DESC,
        match_percent DESC
");

$stmt->execute([
    "student_id"   => $student_id,
    "student_cgpa" => $student_cgpa
]);

$recommended_jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html>
<head>
<title>Student Dashboard</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-primary px-3">
    <span class="navbar-brand mb-0 h1">Student Dashboard</span>
    <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
</nav>

<div class="container mt-4">

<!---------------- PROFILE ---------------->
<div class="card shadow-sm p-4 mb-4">
    <h3 class="text-primary fw-bold mb-3">Welcome, <?= htmlspecialchars($student["full_name"]) ?></h3>

    <div class="row">
        <div class="col-md-6">
            <h5 class="text-secondary">Profile</h5>
            <p>Email: <?= htmlspecialchars($student["email"]) ?></p>
            <p>CGPA: <?= htmlspecialchars($student_cgpa) ?></p>

            <h6 class="mt-3">Skills:</h6>
            <?php if ($student_skills): ?>
                <ul>
                    <?php foreach ($student_skills as $s): ?>
                        <li><?= htmlspecialchars($s["skill_name"]) ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No skills added.</p>
            <?php endif; ?>

            <a href="student_profile.php" class="btn btn-primary btn-sm">Edit Profile</a>
            <a href="student_skills.php" class="btn btn-warning btn-sm">Manage Skills</a>
        </div>

        <div class="col-md-6">
            <h5 class="text-secondary">Resumes</h5>
            <p>You have <?= $resume_count ?> resume(s).</p>
            <a href="resume_upload.php" class="btn btn-success btn-sm">Upload Resume</a>
            <a href="resume_list.php" class="btn btn-secondary btn-sm">View Resumes</a>
        </div>
    </div>
</div>

<!---------------- RECOMMENDED JOBS ---------------->
<div class="card shadow-sm p-4 mb-4">
    <h4 class="text-dark fw-bold">🔥 Recommended Jobs</h4>

    <?php if (!$recommended_jobs): ?>
        <p class="text-muted">No job recommendations available yet.</p>
    <?php else: ?>
        <?php foreach ($recommended_jobs as $job): ?>
            <div class="border rounded p-3 mb-2">
                <strong>
                    <a href="student_job_view.php?job_id=<?= $job["job_id"] ?>" class="text-decoration-none">
                        <?= htmlspecialchars($job["title"]) ?>
                    </a>
                </strong>
                <br>
                <?= htmlspecialchars($job["company_name"]) ?><br>
                🎯 <?= round($job["match_percent"]) ?>% skill match<br>
                <?= $job["gpa_eligible"] ? "🟢 Eligible" : "🔴 GPA requirement not met" ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!---------------- JOB EXPLORATION ---------------->
<div class="card shadow-sm p-4 mb-4">
    <h5 class="text-secondary mb-3">Job Exploration</h5>
    <a href="student_jobs.php" class="btn btn-outline-primary btn-sm">Browse Jobs</a>
    <a href="student_saved_jobs.php" class="btn btn-outline-warning btn-sm">Saved Jobs ⭐</a>
</div>

<!---------------- APPS + CHATS ---------------->
<div class="card shadow-sm p-4 mb-4">
    <h5 class="text-secondary mb-3">Applications & Messages</h5>

    <a href="student_applications.php" class="btn btn-outline-primary btn-sm mb-2">
        View Applications
        <?php if ($unread_notifications > 0): ?>
            <span class="badge bg-danger"><?= $unread_notifications ?></span>
        <?php endif; ?>
    </a>
    <br>

    <a href="student_chats.php" class="btn btn-outline-success btn-sm">
        Messages / Chat Requests
        <?php if ($pending_chats > 0): ?>
            <span class="badge bg-danger"><?= $pending_chats ?></span>
        <?php endif; ?>
    </a>
</div>

</div>
</body>
</html>
