<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}

$student_id = $_SESSION["user_id"];

$stmt = $pdo->prepare("SELECT * FROM students WHERE student_id = ?");
$stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
</head>
<body>

<h2>Edit Profile</h2>

<form method="POST" action="student_profile_update.php">

<label>Full Name</label><br>
<input type="text" name="full_name"
value="<?= htmlspecialchars($student['full_name'] ?? '') ?>" required><br><br>

<label>University</label><br>
<input type="text" name="university"
value="<?= htmlspecialchars($student['university'] ?? '') ?>"><br><br>

<label>Major</label><br>
<input type="text" name="major"
value="<?= htmlspecialchars($student['major'] ?? '') ?>"><br><br>

<label>CGPA</label><br>
<input type="text" name="cgpa"
value="<?= htmlspecialchars($student['cgpa'] ?? '') ?>"><br><br>

<label>Graduation Year</label><br>
<input type="number" name="graduation_year"
value="<?= htmlspecialchars($student['graduation_year'] ?? '') ?>"><br><br>

<button type="submit">Save Profile</button>

</form>

<a href="student_dashboard.php">Back</a>

</body>
</html>
