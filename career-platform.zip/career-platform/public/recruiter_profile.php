<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

$recruiter_id = $_SESSION["user_id"];

$stmt = $pdo->prepare("SELECT * FROM recruiters WHERE recruiter_id = ?");
$stmt->execute([$recruiter_id]);
$recruiter = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Recruiter Profile</title>
</head>
<body>

<h2>Edit Recruiter Profile</h2>

<form method="POST" action="recruiter_profile_update.php">

    <label>Full Name:</label><br>
    <input type="text" name="full_name"
           value="<?= htmlspecialchars($recruiter["full_name"] ?? "") ?>" required><br><br>

    <label>Designation:</label><br>
    <input type="text" name="designation"
           value="<?= htmlspecialchars($recruiter["designation"] ?? "") ?>"><br><br>

    <label>Phone Number:</label><br>
    <input type="text" name="phone"
           value="<?= htmlspecialchars($recruiter["phone"] ?? "") ?>"><br><br>

    <button type="submit">💾 Save Profile</button>
</form>

<br>
<a href="recruiter_dashboard.php">⬅️ Back to Dashboard</a>

</body>
</html>
