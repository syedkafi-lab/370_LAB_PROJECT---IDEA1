<?php
session_start();
require_once "../config/db.php";

/* ===========================
   AUTH CHECK
=========================== */
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    die("Unauthorized");
}

$recruiter_id = $_SESSION["user_id"];

if (!isset($_GET["conversation_id"])) {
    die("Conversation ID missing.");
}

$conversation_id = (int)$_GET["conversation_id"];

/* ===========================
   VERIFY CONVERSATION
=========================== */
$stmt = $pdo->prepare("
    SELECT 
        c.conversation_id,
        c.student_id,
        c.status,
        s.full_name AS student_name
    FROM conversations c
    JOIN students s ON c.student_id = s.student_id
    WHERE c.conversation_id = ?
      AND c.recruiter_id = ?
      AND c.status = 'active'
");
$stmt->execute([$conversation_id, $recruiter_id]);
$conversation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$conversation) {
    die("Chat not available or unauthorized.");
}

/* ===========================
   FETCH MESSAGES
=========================== */
$stmt = $pdo->prepare("
    SELECT sender_role, message, created_at
    FROM messages
    WHERE conversation_id = ?
    ORDER BY created_at ASC
");
$stmt->execute([$conversation_id]);
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Chat with <?= htmlspecialchars($conversation["student_name"]) ?></title>
    <meta charset="UTF-8">
</head>
<body>

<h2>💬 Chat with <?= htmlspecialchars($conversation["student_name"]) ?></h2>

<!-- SAFE BACK (NO BROKEN LINK) -->
<a href="recruiter_selected_applicants.php">⬅ Back</a>




<hr>

<!-- ===========================
     CHAT BOX
=========================== -->
<div style="border:1px solid #ccc; padding:10px; height:320px; overflow-y:auto;">
<?php if (!$messages): ?>
    <p>No messages yet.</p>
<?php else: ?>
    <?php foreach ($messages as $msg): ?>
        <p>
            <strong>
                <?= $msg["sender_role"] === "recruiter" ? "You" : "Student" ?>:
            </strong>
            <?= nl2br(htmlspecialchars($msg["message"])) ?><br>
            <small><?= htmlspecialchars($msg["created_at"]) ?></small>
        </p>
        <hr>
    <?php endforeach; ?>
<?php endif; ?>
</div>

<br>

<!-- ===========================
     SEND MESSAGE
=========================== -->
<form method="POST" action="recruiter_send_message.php">
    <input type="hidden" name="conversation_id" value="<?= $conversation_id ?>">
    <textarea name="message" rows="3" cols="60" required></textarea><br><br>
    <button type="submit">📨 Send</button>
</form>

<hr>

<!-- ===========================
     END CHAT (EXISTING FILE)
=========================== -->
<form method="POST" action="chat_end.php"
      onsubmit="return confirm('End this chat? You will no longer be able to message this student.');">
    <input type="hidden" name="conversation_id" value="<?= $conversation_id ?>">
    <button style="color:red;">🚫 End Chat</button>
</form>

</body>
</html>
