<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

$recruiter_id = $_SESSION["user_id"];

/* FETCH RECRUITER + USER */
$stmt = $pdo->prepare("
    SELECT r.full_name, r.designation, r.phone, u.email
    FROM recruiters r
    JOIN users u ON r.recruiter_id = u.user_id
    WHERE r.recruiter_id = ?
");
$stmt->execute([$recruiter_id]);
$recruiter = $stmt->fetch(PDO::FETCH_ASSOC);

/* FETCH COMPANY */
$stmt = $pdo->prepare("
    SELECT *
    FROM companies
    WHERE recruiter_id = ?
");
$stmt->execute([$recruiter_id]);
$company = $stmt->fetch(PDO::FETCH_ASSOC);

/* COUNT SELECTED APPLICANTS */
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM applications a
    JOIN job_postings j ON a.job_id = j.job_id
    WHERE a.status = 'Selected'
      AND j.recruiter_id = ?
");
$stmt->execute([$recruiter_id]);
$selected_count = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html>
<head>
<title>Recruiter Dashboard</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-primary px-3">
    <span class="navbar-brand mb-0 h1">Recruiter Dashboard</span>
    <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
</nav>

<div class="container mt-4">

<div class="card shadow-sm p-4 mb-4">
    <h3 class="text-primary fw-bold mb-3">Welcome, <?= htmlspecialchars($recruiter["full_name"]) ?></h3>

    <div class="row">
        <div class="col-md-6">
            <h5 class="text-secondary">Profile</h5>
            <p><strong>Designation:</strong> <?= htmlspecialchars($recruiter["designation"] ?? "Not set") ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($recruiter["email"]) ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($recruiter["phone"] ?? "Not set") ?></p>
            <a href="recruiter_profile.php" class="btn btn-primary btn-sm">Edit Profile</a>
        </div>

        <div class="col-md-6">
            <h5 class="text-secondary">Company</h5>
            <?php if (!$company): ?>
                <a href="company_profile.php" class="btn btn-warning btn-sm">Create Company Profile</a>
            <?php else: ?>
                <p><strong><?= htmlspecialchars($company["company_name"]) ?></strong></p>
                <p><?= htmlspecialchars($company["industry"]) ?> — <?= htmlspecialchars($company["location"]) ?></p>
                <a href="company_profile.php" class="btn btn-primary btn-sm">Edit Company</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="card shadow-sm p-4 mb-4">
    <h5 class="text-secondary mb-3">Job Management</h5>
    <?php if ($company): ?>
        <a href="job_create.php" class="btn btn-success btn-sm mb-2">+ Create Job</a><br>
        <a href="recruiter_jobs.php" class="btn btn-outline-primary btn-sm">📌 View Jobs</a>
    <?php endif; ?>
</div>

<div class="card shadow-sm p-4 mb-4">
    <h5 class="text-secondary mb-3">Applicants</h5>
    <a href="recruiter_selected_applicants.php" class="btn btn-outline-primary btn-sm">
        ⭐ Selected Applicants
        <?php if ($selected_count > 0): ?>
            <span class="badge bg-success"><?= $selected_count ?></span>
        <?php endif; ?>
    </a>
</div>

</div>
</body>
</html>
