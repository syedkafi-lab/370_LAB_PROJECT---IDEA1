<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Resume</title>
</head>
<body>

<h2>Upload Resume</h2>

<form action="resume_upload_save.php" method="POST" enctype="multipart/form-data">
    <input type="file" name="resume" accept=".pdf,.doc,.docx" required><br><br>
    <button type="submit">Upload</button>
</form>

<br>
<a href="student_dashboard.php">⬅ Back</a>

</body>
</html>
