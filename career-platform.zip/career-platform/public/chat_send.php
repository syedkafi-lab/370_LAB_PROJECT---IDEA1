<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["role"])) exit;

$conversation_id = $_POST["conversation_id"] ?? null;
$message = trim($_POST["message"] ?? "");

if (!$conversation_id || !$message) exit;

$stmt = $pdo->prepare("
    INSERT INTO messages (conversation_id, sender_role, message)
    VALUES (?, ?, ?)
");
$stmt->execute([
    $conversation_id,
    $_SESSION["role"],
    $message
]);
