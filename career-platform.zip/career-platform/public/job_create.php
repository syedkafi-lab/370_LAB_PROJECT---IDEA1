<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

$stmt = $pdo->prepare(
    "SELECT company_id FROM companies WHERE recruiter_id = ?"
);
$stmt->execute([$_SESSION["user_id"]]);
$company = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$company) {
    die("❌ Please create a company profile first.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Job</title>
</head>
<body>

<h2>📄 Create Job Posting</h2>

<form method="POST" action="job_create_save.php">

    Job Title:<br>
    <input type="text" name="title" required><br><br>

    Job Description:<br>
    <textarea name="description" required></textarea><br><br>

    Required Skills (comma separated):<br>
    <input type="text" name="skills" placeholder="PHP, Laravel, MySQL"><br><br>

    Minimum GPA:<br>
    <input type="number" step="0.01" name="min_gpa"><br><br>

    Job Type:<br>
    <select name="job_type" required>
        <option value="Internship">Internship</option>
        <option value="Full-time">Full-time</option>
        <option value="Part-time">Part-time</option>
    </select><br><br>

    Location:<br>
    <input type="text" name="location"><br><br>

    Stipend / Salary:<br>
    <input type="text" name="stipend_salary"><br><br>

    <button type="submit">Post Job</button>
</form>

</body>
</html>
