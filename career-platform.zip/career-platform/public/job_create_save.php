<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

$recruiter_id = $_SESSION["user_id"];

/* FETCH COMPANY */
$stmt = $pdo->prepare("SELECT company_id FROM companies WHERE recruiter_id = ?");
$stmt->execute([$recruiter_id]);
$company = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$company) {
    die("Company profile missing.");
}

/* INSERT JOB */
$stmt = $pdo->prepare("
    INSERT INTO job_postings
    (recruiter_id, company_id, title, description, min_gpa, job_type, location, stipend_salary)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
");

$stmt->execute([
    $recruiter_id,
    $company["company_id"],
    $_POST["title"],
    $_POST["description"],
    $_POST["min_gpa"] ?: null,
    $_POST["job_type"],
    $_POST["location"],
    $_POST["stipend_salary"]
]);

$job_id = $pdo->lastInsertId();

/* ===========================
   HANDLE SKILLS (SAFE)
=========================== */

$skills = explode(",", $_POST["required_skills"]);

foreach ($skills as $skill_name) {

    $skill_name = strtolower(trim($skill_name));
    if ($skill_name === "") continue;

    // insert or ignore
    $stmt = $pdo->prepare("
        INSERT INTO skills (skill_name)
        VALUES (?)
        ON DUPLICATE KEY UPDATE skill_name = skill_name
    ");
    $stmt->execute([$skill_name]);

    // fetch skill id
    $stmt = $pdo->prepare("
        SELECT skill_id FROM skills WHERE skill_name = ?
    ");
    $stmt->execute([$skill_name]);
    $skill_id = $stmt->fetchColumn();

    // link job ↔ skill
    $stmt = $pdo->prepare("
        INSERT IGNORE INTO job_skills (job_id, skill_id)
        VALUES (?, ?)
    ");
    $stmt->execute([$job_id, $skill_id]);
}


header("Location: recruiter_jobs.php");
exit;
