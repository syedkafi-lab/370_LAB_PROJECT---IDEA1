<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

$stmt = $pdo->prepare("
    UPDATE companies
    SET company_name = ?, industry = ?, location = ?, description = ?
    WHERE recruiter_id = ?
");

$stmt->execute([
    $_POST["company_name"],
    $_POST["industry"],
    $_POST["location"],
    $_POST["description"],
    $_SESSION["user_id"]
]);

header("Location: recruiter_dashboard.php");
exit;
