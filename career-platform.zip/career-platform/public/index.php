<?php
// No session needed here, just a simple landing page
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Career Platform - Home</title>
    <!-- Bootstrap 5 CDN -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >
</head>
<body class="bg-light">

<div class="min-vh-100 d-flex align-items-center justify-content-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">

                <div class="text-center mb-4">
                    <h1 class="fw-bold">Career Platform</h1>
                    <p class="text-muted">Smart Resume & Job Matching Portal</p>
                </div>

                <div class="card shadow-sm">
                    <div class="card-body text-center">

                        <h5 class="card-title mb-3">Welcome</h5>
                        <p class="text-muted mb-4">
                            Please choose how you want to continue.
                        </p>

                        <div class="d-grid gap-3">
                            <a href="login.php" class="btn btn-primary btn-lg">
                                🔐 Login
                            </a>
                            <a href="register.php" class="btn btn-outline-secondary btn-lg">
                                🆕 Register
                            </a>
                        </div>

                    </div>
                </div>

                <p class="text-center mt-3 text-muted" style="font-size: 0.85rem;">
                    BRAC University · CSE Project
                </p>

            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS (optional, for components like modals) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
