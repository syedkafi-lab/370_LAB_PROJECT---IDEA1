<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || !isset($_SESSION["role"])) {
    die("Unauthorized");
}

$user_id = $_SESSION["user_id"];
$role = $_SESSION["role"];

$conversation_id = $_POST["conversation_id"] ?? null;
if (!$conversation_id) die("Conversation missing.");

$stmt = $pdo->prepare("SELECT * FROM conversations WHERE conversation_id = ?");
$stmt->execute([$conversation_id]);
$conv = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$conv) die("Conversation not found.");

if ($role === "student" && (int)$conv["student_id"] !== (int)$user_id) die("Unauthorized");
if ($role === "recruiter" && (int)$conv["recruiter_id"] !== (int)$user_id) die("Unauthorized");

$pdo->prepare("UPDATE conversations SET status = 'ended' WHERE conversation_id = ?")
    ->execute([$conversation_id]);

if ($role === "student") {
    header("Location: student_chats.php");
} else {
    header("Location: recruiter_selected_applicants.php");
}
exit;
