<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    die("Unauthorized");
}

if (!isset($_GET["job_id"])) {
    die("Job ID missing");
}

$student_id = $_SESSION["user_id"];
$job_id = $_GET["job_id"];

/* FETCH RESUMES */
$stmt = $pdo->prepare("
    SELECT resume_id, file_name
    FROM resumes
    WHERE student_id = ?
");
$stmt->execute([$student_id]);
$resumes = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($resumes) === 0) {
    die("No resume found. Upload resume first.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Select Resume</title>
</head>
<body>

<h2>Select Resume Before Applying</h2>

<form method="POST" action="student_apply_save.php">

    <input type="hidden" name="job_id" value="<?= $job_id ?>">

    <label><strong>Choose Resume:</strong></label><br><br>

    <select name="resume_id" required>
        <option value="">-- Select Resume --</option>
        <?php foreach ($resumes as $r): ?>
            <option value="<?= $r["resume_id"] ?>">
                <?= htmlspecialchars($r["file_name"]) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <br><br>
    <button type="submit">Submit Application</button>

</form>

</body>
</html>
