<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    die("Unauthorized");
}

$student_id = $_SESSION["user_id"];
$conversation_id = $_POST["conversation_id"] ?? null;

if (!$conversation_id) die("Conversation missing.");

$stmt = $pdo->prepare("
    UPDATE conversations
    SET status = 'active'
    WHERE conversation_id = ?
      AND student_id = ?
      AND status = 'pending'
");
$stmt->execute([$conversation_id, $student_id]);

header("Location: student_chats.php");
exit;
