<?php
session_start();
require_once "../config/db.php";

/* ===========================
   AUTH CHECK
=========================== */
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    die("Unauthorized");
}

if (empty($_POST["conversation_id"]) || empty($_POST["message"])) {
    die("Invalid request");
}

$recruiter_id   = $_SESSION["user_id"];
$conversation_id = (int)$_POST["conversation_id"];
$message        = trim($_POST["message"]);

/* ===========================
   VERIFY ACTIVE CONVERSATION
=========================== */
$stmt = $pdo->prepare("
    SELECT conversation_id
    FROM conversations
    WHERE conversation_id = ?
      AND recruiter_id = ?
      AND status = 'active'
");
$stmt->execute([$conversation_id, $recruiter_id]);

if (!$stmt->fetch()) {
    die("Chat not allowed.");
}

/* ===========================
   INSERT MESSAGE
=========================== */
$stmt = $pdo->prepare("
    INSERT INTO messages (conversation_id, sender_role, message, created_at)
    VALUES (?, 'recruiter', ?, NOW())
");
$stmt->execute([$conversation_id, $message]);

header("Location: recruiter_chat.php?conversation_id=" . $conversation_id);
exit;
