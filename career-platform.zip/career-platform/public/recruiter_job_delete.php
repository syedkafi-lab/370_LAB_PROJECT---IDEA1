<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

$recruiter_id = $_SESSION["user_id"];

if (!isset($_GET["job_id"])) {
    die("Job ID missing.");
}

$job_id = (int) $_GET["job_id"];

/* ===========================
   VERIFY RECRUITER OWNS JOB
=========================== */
$stmt = $pdo->prepare("
    SELECT j.title
    FROM job_postings j
    JOIN companies c ON j.company_id = c.company_id
    WHERE j.job_id = ?
      AND c.recruiter_id = ?
");
$stmt->execute([$job_id, $recruiter_id]);
$job = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$job) {
    die("Unauthorized job delete.");
}

$job_title = $job["title"];

/* ===========================
   MARK JOB INACTIVE
=========================== */
$stmt = $pdo->prepare("
    UPDATE job_postings
    SET is_active = 0
    WHERE job_id = ?
");
$stmt->execute([$job_id]);

/* ===========================
   MARK APPLICATIONS AS REMOVED
=========================== */
$stmt = $pdo->prepare("
    UPDATE applications
    SET status = 'job_removed'
    WHERE job_id = ?
");
$stmt->execute([$job_id]);

/* ===========================
   FETCH ALL AFFECTED STUDENTS
=========================== */
$stmt = $pdo->prepare("
    SELECT DISTINCT student_id 
    FROM applications
    WHERE job_id = ?
");
$stmt->execute([$job_id]);
$students = $stmt->fetchAll(PDO::FETCH_COLUMN);

/* ===========================
   SEND NOTIFICATIONS
=========================== */
foreach ($students as $sid) {

    $stmt2 = $pdo->prepare("
        INSERT INTO notifications (user_id, message, is_read, created_at)
        VALUES (?, ?, 0, NOW())
    ");

    $stmt2->execute([
        $sid,
        "⚠ The job '{$job_title}' you applied to has been removed by the recruiter."
    ]);
}

/* ===========================
   REDIRECT BACK
=========================== */
header("Location: recruiter_jobs.php");
exit;
