<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || !isset($_SESSION["role"])) {
    die("Unauthorized");
}

$user_id = (int)$_SESSION["user_id"];
$role = $_SESSION["role"];
$conversation_id = (int)($_POST["conversation_id"] ?? 0);

if (!$conversation_id) die("Conversation missing.");

$stmt = $pdo->prepare("SELECT * FROM conversations WHERE conversation_id = ?");
$stmt->execute([$conversation_id]);
$c = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$c) die("Conversation not found.");

if ($role === "student" && (int)$c["student_id"] !== $user_id) die("Unauthorized");
if ($role === "recruiter" && (int)$c["recruiter_id"] !== $user_id) die("Unauthorized");

if (!in_array($c["status"], ["ended", "locked"])) {
    die("You can only dismiss ended/locked chats.");
}

if ($role === "student") {
    $pdo->prepare("UPDATE conversations SET student_hidden = 1 WHERE conversation_id = ?")
        ->execute([$conversation_id]);
    header("Location: student_chats.php");
} else {
    $pdo->prepare("UPDATE conversations SET recruiter_hidden = 1 WHERE conversation_id = ?")
        ->execute([$conversation_id]);
    header("Location: recruiter_selected_applicants.php");
}
exit;
