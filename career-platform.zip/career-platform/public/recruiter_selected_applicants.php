<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "recruiter") {
    header("Location: login.php");
    exit;
}

$recruiter_id = $_SESSION["user_id"];

/* ===========================
   FETCH SELECTED APPLICANTS
=========================== */
$stmt = $pdo->prepare("
    SELECT 
        a.application_id,
        s.full_name,
        u.email,
        j.title AS job_title,

        c.conversation_id,
        c.status AS chat_status

    FROM applications a

    JOIN students s ON a.student_id = s.student_id
    JOIN users u ON s.student_id = u.user_id
    JOIN job_postings j ON a.job_id = j.job_id

    LEFT JOIN conversations c
        ON c.application_id = a.application_id

    WHERE a.status = 'Selected'
      AND j.recruiter_id = ?

    ORDER BY a.application_id DESC
");
$stmt->execute([$recruiter_id]);
$applicants = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Selected Applicants</title>
</head>
<body>

<h2>⭐ Selected Applicants</h2>

<?php if (!$applicants): ?>
    <p>No selected applicants yet.</p>
<?php else: ?>

<table border="1" cellpadding="8">
<tr>
    <th>Student</th>
    <th>Email</th>
    <th>Job</th>
    <th>Chat</th>
</tr>

<?php foreach ($applicants as $a): ?>
<tr>
    <td><?= htmlspecialchars($a["full_name"]) ?></td>
    <td><?= htmlspecialchars($a["email"]) ?></td>
    <td><?= htmlspecialchars($a["job_title"]) ?></td>

    <td>

        <?php if (!$a["conversation_id"]): ?>

            <form method="POST" action="recruiter_start_chat.php">
                <input type="hidden" name="application_id" 
                       value="<?= $a["application_id"] ?>">
                <button type="submit">💬 Start Chat</button>
            </form>

        <?php else: ?>

            <?php if ($a["chat_status"] === "active"): ?>
                <a href="chat.php?conversation_id=<?= $a["conversation_id"] ?>">
                    💬 Open Chat
                </a>

            <?php elseif ($a["chat_status"] === "pending"): ?>
                ⏳ Waiting for student...

            <?php elseif ($a["chat_status"] === "locked"): ?>
                🔒 Chat locked

            <?php elseif ($a["chat_status"] === "ended"): ?>
                🛑 Chat ended

            <?php else: ?>
                🚫 Unknown chat state
            <?php endif; ?>

        <?php endif; ?>

    </td>
</tr>
<?php endforeach; ?>

</table>

<?php endif; ?>

<br>
<a href="recruiter_dashboard.php">⬅ Back</a>

</body>
</html>
