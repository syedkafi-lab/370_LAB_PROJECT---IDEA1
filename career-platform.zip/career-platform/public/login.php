<?php
session_start();
require_once "../config/db.php";

$message = "";

// Show success message if redirected from register
if (isset($_GET["registered"]) && $_GET["registered"] == "1") {
    $message = "✅ Registration successful! Please login.";
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email    = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($email === "" || $password === "") {
        $message = "❌ Email and password are required.";
    } else {

        $stmt = $pdo->prepare("
            SELECT user_id, email, password_hash, role
            FROM users
            WHERE email = :email AND is_active = 1
        ");
        $stmt->execute([":email" => $email]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user["password_hash"])) {

            // 🔐 Security: regenerate session ID
            session_regenerate_id(true);

            // ✅ Store session data
            $_SESSION["user_id"] = $user["user_id"];
            $_SESSION["email"]   = $user["email"];
            $_SESSION["role"]    = $user["role"];

            /* =====================================
               STUDENT AUTO PROFILE CREATION
               ===================================== */
            if ($user["role"] === "student") {

                $check = $pdo->prepare("
                    SELECT student_id 
                    FROM students 
                    WHERE student_id = ?
                ");
                $check->execute([$user["user_id"]]);

                if (!$check->fetch()) {
                    $insert = $pdo->prepare("
                        INSERT INTO students (student_id) 
                        VALUES (?)
                    ");
                    $insert->execute([$user["user_id"]]);
                }

                header("Location: student_dashboard.php");
                exit;
            }

            /* =====================================
               RECRUITER AUTO PROFILE CREATION
               ===================================== */
            if ($user["role"] === "recruiter") {

                $check = $pdo->prepare("
                    SELECT recruiter_id 
                    FROM recruiters 
                    WHERE recruiter_id = ?
                ");
                $check->execute([$user["user_id"]]);

                if (!$check->fetch()) {
                    $insert = $pdo->prepare("
                        INSERT INTO recruiters (recruiter_id) 
                        VALUES (?)
                    ");
                    $insert->execute([$user["user_id"]]);
                }

                header("Location: recruiter_dashboard.php");
                exit;
            }

            /* =====================================
               ADMIN REDIRECT
               ===================================== */
            if ($user["role"] === "admin") {
                header("Location: admin_dashboard.php");
                exit;
            }

        } else {
            $message = "❌ Invalid email or password.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login | Career Platform</title>
    <!-- Bootstrap 5 CDN -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >
</head>
<body class="bg-light">

<div class="min-vh-100 d-flex align-items-center justify-content-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5 col-lg-4">

                <div class="text-center mb-4">
                    <h2 class="fw-bold">Career Platform</h2>
                    <p class="text-muted">Login to continue</p>
                </div>

                <div class="card shadow-sm">
                    <div class="card-body">

                        <h4 class="card-title mb-3 text-center">🔐 Login</h4>

                        <?php if ($message !== ""): ?>
                            <?php
                                // Simple heuristic: success vs error alert
                                $isSuccess = strpos($message, "✅") !== false;
                                $alertClass = $isSuccess ? "alert-success" : "alert-danger";
                            ?>
                            <div class="alert <?= $alertClass ?> py-2">
                                <?= htmlspecialchars($message) ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" novalidate>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address</label>
                                <input
                                    type="email"
                                    class="form-control"
                                    id="email"
                                    name="email"
                                    required
                                    autocomplete="email"
                                >
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input
                                    type="password"
                                    class="form-control"
                                    id="password"
                                    name="password"
                                    required
                                    autocomplete="current-password"
                                >
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">
                                    Login
                                </button>
                            </div>
                        </form>

                        <p class="mt-3 mb-0 text-center">
                            New user?
                            <a href="register.php">Create an account</a>
                        </p>

                        <p class="mt-1 text-center">
                            <a href="index.php" class="text-muted" style="font-size:0.85rem;">
                                ⬅ Back to Home
                            </a>
                        </p>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
