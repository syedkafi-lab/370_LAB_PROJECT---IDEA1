<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "student") {
    die("Unauthorized");
}

if (empty($_POST["job_id"]) || empty($_POST["resume_id"])) {
    die("Invalid request.");
}

$student_id = $_SESSION["user_id"];
$job_id = $_POST["job_id"];
$resume_id = $_POST["resume_id"];

/* BLOCK IF JOB REMOVED */
$stmt = $pdo->prepare("SELECT is_active FROM job_postings WHERE job_id = ?");
$stmt->execute([$job_id]);
$is_active = $stmt->fetchColumn();

if (!$is_active) {
    die("🚫 This job posting is no longer available.");
}

/* FETCH GPA */
$stmt = $pdo->prepare("
    SELECT j.min_gpa, s.cgpa
    FROM job_postings j
    JOIN students s ON s.student_id = ?
    WHERE j.job_id = ?
");
$stmt->execute([$student_id, $job_id]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$data) {
    die("Job not found.");
}

if ($data["min_gpa"] !== null && $data["cgpa"] < $data["min_gpa"]) {
    die("You do not meet the GPA requirement.");
}

/* INSERT APPLICATION */
$stmt = $pdo->prepare("
    INSERT INTO applications (student_id, job_id, resume_id, status)
    VALUES (?, ?, ?, 'Applied')
");
$stmt->execute([$student_id, $job_id, $resume_id]);

header("Location: student_dashboard.php");
exit;
