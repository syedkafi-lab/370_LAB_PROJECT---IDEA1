<?php
define("AFFINDA_API_KEY", "PASTE_YOUR_API_KEY_HERE");
define("AFFINDA_API_URL", "https://api.affinda.com/v2/resumes");
